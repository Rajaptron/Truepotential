<?php


if(isset($_POST['membership'])){
    
    if($_POST['membership']=='Free')
    {
        $res="update user set status='Free' where sno='$usid'";                      
        $result = mysqli_query($con,$res);
        header("location:upload_documents.php");
    }
    else if($_POST['membership']=='Paid')
    {
        
    }
    
}

?>

<!doctype html>
<html lang="en">


<head>
<title>Pricing - True Potential</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="HexaBit Bootstrap 4x Admin Template">
<meta name="author" content="WrapTheme, www.thememakker.com">

<link rel="icon" href="favicon.ico" type="image/x-icon">
<!-- VENDOR CSS -->
<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/color_skins.css">
</head>
<body class="theme-orange">

    <!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="https://thememakker.com/templates/hexabit/html/assets/images/icon-light.svg" width="48" height="48" alt="HexaBit"></div>
        <p>Please wait...</p>        
    </div>
</div>
<!-- Overlay For Sidebars -->
<div class="overlay"></div>

<div id="wrapper">

  <?php
  
  include 'include/top-nav.php';
  ?>

    

    <?php
    
    
    include 'include/side-nav.php';
    
    ?>

    <div id="main-content">
   
        <div class="container-fluid">           

            
            <div class="row clearfix">
                <div class="col-12">
                    <hr>
                </div>
                
                    
                <div class="col-lg-6 col-md-12">
                    <div class="card pricing2">
                        <div class="body">
                            <div class="pricing-plan">
                                <img src="assets/images/chair1.png" alt="" class="pricing-img">
                                <h2 class="pricing-header">Basic</h2>
                                <ul class="pricing-features">
                                    <li>Feature-1</li>
                                    <li>Feature-2</li>
                                    <li>Feature-3</li>
                                    <li>Feature-4</li>
                                </ul>
                                <span class="pricing-price">Free</span>
                                <form method="POST" action="#">
                                <button type="submit" name="membership" value="Free" class="btn btn-outline-primary">Select</button>
                                </form>
                              </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="card pricing2">
                        <div class="body">
                            <div class="pricing-plan">
                                <img src="assets/images/chair2.png" alt="" class="pricing-img">
                                <h2 class="pricing-header">Standard</h2>
                                <ul class="pricing-features">
                                    <li>Feature-1</li>
                                    <li>Feature-2</li>
                                    <li>Feature-3</li>
                                    <li>Feature-4</li>
                                </ul>
                                <span class="pricing-price">749 /-</span>
                                <form method="POST" action="#">
                                <button type="submit" name="membership" value="Paid" class="btn btn-primary">Select</button>
                                </form>
                              </div>
                        </div>
                    </div>
                </div>
                    
               
                
            </div>

            

        </div>
    </div>
    
</div>

<!-- Javascript -->
<script src="assets/bundles/libscripts.bundle.js"></script>    
<script src="assets/bundles/vendorscripts.bundle.js"></script>

<script src="assets/bundles/mainscripts.bundle.js"></script>
</body>

</html>
