<?php

	define('XPEEDSTUDIO_EMAIL', 'mail@example.com');
	define('XPEEDSTUDIO_SUBJECT', 'New Contact Email');
	define('XPEEDSTUDIO_SUCCESS_MASSAGE', 'Successfully Sent Email');

?>