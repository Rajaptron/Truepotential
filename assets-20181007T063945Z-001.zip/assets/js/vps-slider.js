let products = [
            
    {
        name     : 'Basic Pack',
        price	 : '$5.99',
        desc	 : 'It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name',
        cpu	 : '1 Core',
        brandwidth: '100 GB',
        brandwidth2: '.5 TB',
        ram: '1 GB' ,
        setup: 'Paid',
        setup2: 'Free',
        diskspace: '100 GB',
        ipOne: 'Up to 1',
        ipTwo: 'Up to 0',
        urlLink: 'http://whmcs.finesttheme.com/cart.php?a=add&pid=3'
    },
    
    {
        name     : 'Starter Pack',
        price	 : '$10.99',
        desc	 : ' Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.',
        cpu	 : '2 Core',
        brandwidth: '500 GB',
        brandwidth2: '1 TB',
        ram: '2 GB' ,
        setup: 'Free',
        setup2: 'Paid',
        diskspace: '200 GB',
        ipOne: 'Up to 3',
        ipTwo: 'Up to 2',
        urlLink: 'http://whmcs.finesttheme.com/cart.php?a=add&pid=6'
    },
    
    {
        name     : 'Enterprise Pack',
        price	 : '$15.99',
        desc	 : 'It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name',
        cpu	 : '3 Core',
        brandwidth: '1000 GB',
        brandwidth2: '5 TB',
        ram: '5 GB' ,
        setup: 'Paid',
        setup2: 'Free',
        diskspace: '300 GB',
        ipOne: 'Up to 4',
        ipTwo: 'Up to 6',
        urlLink: 'http://whmcs.finesttheme.com/cart.php?a=add&pid=5'
    },

    {
        name     : 'Business Pack',
        price	 : '$18.99',
        desc	 : 'Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.',
        cpu	 : '5 Core',
        brandwidth: '2000 GB',
        brandwidth2: '50 TB',
        ram: '16 GB' ,
        setup: 'Free',
        setup2: 'Paid',
        diskspace: '400 GB',
        ipOne: 'Up to 8',
        ipTwo: 'Up to 10',
        urlLink: 'http://whmcs.finesttheme.com/cart.php?a=add&pid=10'
    },

    {
        name     : 'Pro Pack',
        price	 : '$20.99',
        desc	 : 'It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name',
        cpu	 : '8 Core',
        brandwidth: 'Unlimited',
        brandwidth2: '500 TB',
        ram: '32 GB' ,
        setup: 'Paid',
        setup2: 'Free',
        diskspace: '500 GB',
        ipOne: 'Up to 9',
        ipTwo: 'Up to 6',
        urlLink: 'http://whmcs.finesttheme.com/cart.php?a=add&pid=11'
    },
];

// let url = 'https://www.domainname.com/?cmd=cart&id=';
// $('.slider-btns').attr('href', url + sliderplans[1][ui.value-1]);