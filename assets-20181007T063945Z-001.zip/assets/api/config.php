<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'vyDaC05AYGjwI4hWCt5Rfvae5');
    define('CONSUMER_SECRET', 'a91ZuyrTNT6FTG5PKrvRoWBVqQxutLA4lfRfiPP4kEn919QCQn');

    // User Access Token
    define('ACCESS_TOKEN', '744248327391186945-wzmmsacC7DoOrLufMOJP0b8OkiKsudT');
    define('ACCESS_SECRET', 'dHB1WC6H4p5RTY0c57PkaUi2N2rnkgXK4gjgP6q3AR2zM');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));